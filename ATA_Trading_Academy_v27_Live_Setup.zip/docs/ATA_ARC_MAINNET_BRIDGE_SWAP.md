# ATA v12 — Arc Mainnet, Real USDC, Bridge and Swap

## Production network

- Arc Mainnet chain ID: 5042 (`0x13b2`)
- RPC: `https://rpc.mainnet.arc.io`
- WebSocket: `wss://rpc.mainnet.arc.io`
- Explorer: `https://explorer.arc.io`
- USDC contract: `0x3600000000000000000000000000000000000000`

## Funding policy

ATA production has **no faucet**. Users fund their connected wallet with real USDC through configured production funding/on-ramp flows.

## Swap

ATA uses an adapter boundary for Arc Swap Kit / LI.FI. The frontend must detect the connected wallet, verify the network, fetch a fresh quote, show output/minimum received/fees/route/price impact when supplied, require explicit wallet confirmation, submit the transaction, track status, and refresh balances after confirmation.

## Bridge

Bridge is a distinct flow: source chain → USDC → Arc Mainnet → recipient wallet → confirmation → balance refresh. A bridge must never be displayed as completed merely because a quote exists or a transaction was submitted.

## Security

- Never put private keys in the frontend.
- Never trust browser-supplied balances.
- Never reuse stale quotes.
- Revalidate amount, chain, token and recipient before execution.
- Prevent duplicate submissions with transaction/request IDs.
- Do not show success until provider/on-chain confirmation.
- Keep provider secrets server-side where required.

## Trading separation

Wallet/DeFi → USDC settlement

Trading terminal → authenticated ATA backend → ExecutionProvider → trading venue

A successful wallet transaction is not a trading fill.
