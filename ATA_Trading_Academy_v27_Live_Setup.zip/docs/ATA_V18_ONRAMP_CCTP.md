# ATA v18 — Arc Onramp + CCTP funding

## Integrated UX

`Fund Wallet` provides two paths:

1. **Buy USDC** — creates a server-side Circle Onramp session for the connected user-controlled wallet.
2. **Bridge USDC** — prepares a native USDC CCTP V2 transfer to Arc Mainnet (domain 26).

After funding, ATA presents the first-action surface: Trade, Swap, Send, Bridge.

## Security boundary

- Circle API credentials remain server-side.
- The browser never receives the Circle API key.
- ATA never receives or stores wallet private keys.
- Wallet transactions must be signed by the user's connected wallet.
- CCTP contract addresses are centralized in `src/lib/cctp/index.ts`.

## Live Circle Onramp configuration

The project deliberately does not invent a Circle API endpoint or SDK call. Configure the current Circle Onramp API base URL and session path from Circle's current developer documentation:

`CIRCLE_API_KEY`
`CIRCLE_ONRAMP_API_BASE_URL`
`CIRCLE_ONRAMP_SESSION_PATH`

Once configured, `/api/onramp/session` forwards the request server-side and returns Circle's session response to the ATA client.

## CCTP V2

Arc Mainnet:
- Chain ID: 5042
- CCTP domain: 26
- USDC: `0x3600000000000000000000000000000000000000`
- TokenMessengerV2: `0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d`
- MessageTransmitterV2: `0x81D40F21F12A8F0E3252Bccb954D722d4c464B64`
- TokenMinterV2: `0xfd78EE919681417d192449715b2594ab58f5D002`

The current scaffold intentionally stops before constructing a CCTP transaction from an unverified ABI. The next production step is to use Circle's current CCTP V2 SDK/transaction builder, have the wallet sign the generated transaction, then track the attestation and receive/mint transaction.
