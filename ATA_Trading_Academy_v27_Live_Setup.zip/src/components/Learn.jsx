import React,{useEffect,useState} from 'react'
import {FOREX_COURSE} from '../lib/lessons/forexCourse'
const KEY='ata-done-lessons'
const load=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){return []}}
const save=v=>{try{localStorage.setItem(KEY,JSON.stringify(v))}catch(e){}}
export default function Learn(){
 const [level,setLevel]=useState('Beginner');const [idx,setIdx]=useState(0);const [done,setDone]=useState([])
 useEffect(()=>setDone(load()),[])
 const lessons=FOREX_COURSE[level];const [title,body]=lessons[idx];const id=level+':'+idx
 function complete(){const n=done.includes(id)?done:[...done,id];setDone(n);save(n);if(idx<lessons.length-1)setIdx(idx+1)}
 const b=on=>({padding:'10px 16px',borderRadius:10,border:'1px solid #30343b',background:on?'#fff':'#15181d',color:on?'#000':'#fff',cursor:'pointer'})
 return <section style={{padding:28,border:'1px solid #292e36',borderRadius:18,background:'#0d1015',marginTop:18}}>
  <h2>Learn forex trading</h2><p style={{color:'#9da5b0'}}>Free to read. No funds needed. Educational content only, not financial advice.</p>
  <div style={{display:'flex',gap:8,flexWrap:'wrap',margin:'14px 0'}}>{Object.keys(FOREX_COURSE).map(l=><button key={l} style={b(l===level)} onClick={()=>{setLevel(l);setIdx(0)}}>{l} · {FOREX_COURSE[l].filter((_,i)=>done.includes(l+':'+i)).length}/{FOREX_COURSE[l].length}</button>)}</div>
  <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:14}}>{lessons.map((l,i)=><button key={i} style={b(i===idx)} onClick={()=>setIdx(i)}>{done.includes(level+':'+i)?'✓ ':''}{i+1}. {l[0]}</button>)}</div>
  <h3>{title}</h3><p style={{lineHeight:1.7,color:'#dce1e8',whiteSpace:'pre-line'}}>{body}</p>
  <button style={{marginTop:14,padding:'13px 20px',background:'#fff',color:'#000',border:0,borderRadius:10,fontWeight:700,cursor:'pointer'}} onClick={complete}>{idx<lessons.length-1?'Mark complete & next':'Mark complete'}</button>
 </section>
}
