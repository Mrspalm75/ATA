import React,{useEffect,useRef,useState} from 'react'
const API=import.meta.env.VITE_API_BASE_URL||'/api'
const IDEAS=['How do I read market structure?','How do I find a good entry on a pullback?','How much should I risk per trade?','How do I stop revenge trading?']
const card={padding:28,border:'1px solid #292e36',borderRadius:18,background:'#0d1015',marginTop:18}
export default function Mentor(){
 const [msgs,setMsgs]=useState([]);const [text,setText]=useState('');const [busy,setBusy]=useState(false);const [err,setErr]=useState('');const end=useRef(null)
 useEffect(()=>{end.current?.scrollIntoView?.({block:'nearest'})},[msgs,busy])
 async function send(q){const content=(q??text).trim();if(!content||busy)return
  const next=[...msgs,{role:'user',content}];setMsgs(next);setText('');setErr('');setBusy(true)
  try{const r=await fetch(`${API}/mentor`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({messages:next})});const j=await r.json();if(!r.ok)throw new Error(j.error||'Mentor unavailable.');setMsgs([...next,{role:'assistant',content:j.reply}])}
  catch(e){setErr(e.message)}finally{setBusy(false)}}
 return <section style={card}><h2>ATA Mentor</h2><p style={{color:'#9da5b0'}}>Ask about market structure, entries, risk or psychology. Educational only, not financial advice.</p>
  {!msgs.length&&<div style={{display:'flex',gap:8,flexWrap:'wrap',margin:'12px 0'}}>{IDEAS.map(i=><button key={i} onClick={()=>send(i)} style={{padding:'9px 14px',borderRadius:20,border:'1px solid #30343b',background:'#15181d',color:'#fff',cursor:'pointer'}}>{i}</button>)}</div>}
  <div style={{display:'grid',gap:10,margin:'12px 0'}}>{msgs.map((m,i)=><div key={i} style={{padding:14,borderRadius:12,whiteSpace:'pre-wrap',lineHeight:1.6,background:m.role==='user'?'#1a2230':'#12161c',border:'1px solid #242830'}}><b style={{color:'#9da5b0',fontSize:12}}>{m.role==='user'?'YOU':'ATA MENTOR'}</b><div>{m.content}</div></div>)}{busy&&<div style={{color:'#9da5b0'}}>ATA Mentor is thinking…</div>}<div ref={end}/></div>
  {err&&<div style={{color:'#f0b429',marginBottom:8}}>{err}</div>}
  <textarea value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}}} placeholder="Ask your mentor…" rows={3} style={{width:'100%',boxSizing:'border-box',padding:13,background:'#111419',color:'#fff',border:'1px solid #30343b',borderRadius:9,font:'inherit'}}/>
  <button disabled={busy||!text.trim()} onClick={()=>send()} style={{marginTop:10,padding:'13px 20px',background:'#fff',color:'#000',border:0,borderRadius:10,fontWeight:700,cursor:'pointer',opacity:busy||!text.trim()?.45:1}}>Ask mentor</button></section>
}
