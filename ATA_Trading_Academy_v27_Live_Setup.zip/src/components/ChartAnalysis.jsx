import React,{useState} from 'react'
const API=import.meta.env.VITE_API_BASE_URL||'/api'
const card={padding:28,border:'1px solid #292e36',borderRadius:18,background:'#0d1015',marginTop:18}
function shrink(file){return new Promise((ok,no)=>{const url=URL.createObjectURL(file);const img=new Image()
 img.onload=()=>{const k=Math.min(1,1600/Math.max(img.width,img.height));const c=document.createElement('canvas');c.width=Math.round(img.width*k);c.height=Math.round(img.height*k);c.getContext('2d').drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(url);ok(c.toDataURL('image/jpeg',0.85))}
 img.onerror=()=>{URL.revokeObjectURL(url);no(new Error('Could not read that image.'))};img.src=url})}
export default function ChartAnalysis(){
 const [preview,setPreview]=useState('');const [note,setNote]=useState('');const [out,setOut]=useState('');const [err,setErr]=useState('');const [busy,setBusy]=useState(false)
 async function pick(e){const f=e.target.files?.[0];if(!f)return;setErr('');setOut('')
  if(!/^image\//.test(f.type)){setErr('Choose an image file.');return}
  try{setPreview(await shrink(f))}catch(x){setErr(x.message)}}
 async function analyse(){if(!preview||busy)return;setBusy(true);setErr('');setOut('')
  try{const r=await fetch(`${API}/chart-analysis`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({image:preview.split(',')[1],mediaType:'image/jpeg',context:note})});const j=await r.json();if(!r.ok)throw new Error(j.error||'Analysis failed.');setOut(j.reply)}
  catch(x){setErr(x.message)}finally{setBusy(false)}}
 return <section style={card}><h2>Chart Analysis</h2><p style={{color:'#9da5b0'}}>Upload any chart screenshot. ATA walks through structure, key levels and risk the way a mentor would talk you through a setup. Educational only, not financial advice.</p>
  <input type="file" accept="image/png,image/jpeg,image/webp" onChange={pick} style={{margin:'10px 0',color:'#cbd1da'}}/>
  {preview&&<img src={preview} alt="Chart preview" style={{maxWidth:'100%',borderRadius:10,border:'1px solid #30343b',display:'block',margin:'10px 0'}}/>}
  <input value={note} onChange={e=>setNote(e.target.value)} placeholder="Optional: pair, timeframe, what you are considering" style={{display:'block',width:'100%',boxSizing:'border-box',padding:13,margin:'10px 0',background:'#111419',color:'#fff',border:'1px solid #30343b',borderRadius:9,font:'inherit'}}/>
  <button disabled={!preview||busy} onClick={analyse} style={{padding:'13px 20px',background:'#fff',color:'#000',border:0,borderRadius:10,fontWeight:700,cursor:'pointer',opacity:!preview||busy?.45:1}}>{busy?'Analysing…':'Analyse chart'}</button>
  {err&&<div style={{color:'#f0b429',marginTop:12}}>{err}</div>}
  {out&&<div style={{marginTop:16,padding:16,border:'1px solid #242830',borderRadius:12,whiteSpace:'pre-wrap',lineHeight:1.65,background:'#12161c'}}>{out}</div>}</section>
}
