export type PaymentRecipient = {
  address: string
  label?: string
  chainId: number
}

export type StablecoinPayment = {
  id: string
  token: string
  amount: string
  recipient: PaymentRecipient
  status: "draft" | "scheduled" | "pending" | "confirmed" | "failed"
  scheduledAt?: string
  createdAt: string
}

export type PaymentRequest = {
  id: string
  token: string
  amount?: string
  recipientAddress: string
  memo?: string
  status: "open" | "paid" | "expired" | "cancelled"
  expiresAt?: string
}

export type BatchPayment = {
  id: string
  token: string
  payments: Array<{recipient: string; amount: string; memo?: string}>
  status: "draft" | "pending" | "confirmed" | "failed"
}

export interface PaymentService {
  send(input: Omit<StablecoinPayment, "id"|"status"|"createdAt">): Promise<StablecoinPayment>
  request(input: Omit<PaymentRequest, "id"|"status">): Promise<PaymentRequest>
  batch(input: Omit<BatchPayment, "id"|"status">): Promise<BatchPayment>
  schedule(input: Omit<StablecoinPayment, "id"|"status"|"createdAt"> & {scheduledAt:string}): Promise<StablecoinPayment>
  saveRecipient(recipient: PaymentRecipient): Promise<PaymentRecipient>
}
