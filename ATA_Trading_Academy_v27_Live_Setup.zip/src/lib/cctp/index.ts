export const ARC_CCTP = {
  domain: 26,
  usdc: '0x3600000000000000000000000000000000000000',
  eurc: '0xbEf5f6d51CB62b58e6A8f77868681825C6fe21c1',
  tokenMessengerV2: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
  messageTransmitterV2: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
  tokenMinterV2: '0xfd78EE919681417d192449715b2594ab58f5D002'
} as const

export type CctpTransferRequest = {
  sourceDomain:number
  amount:string
  sourceWallet:string
  destinationWallet:string
  destinationDomain:number
  asset?:'USDC'|'EURC'
}

export async function createCctpTransfer(req:CctpTransferRequest) {
  const res = await fetch('/api/cctp/transfer', {method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(req)})
  const data = await res.json()
  if (!res.ok) throw new Error(data.error || 'Unable to prepare Arc bridge transfer.')
  return data
}
