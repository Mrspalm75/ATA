export type LessonLevel = "beginner" | "intermediate" | "advanced"

export type Lesson = {
  id: string
  level: LessonLevel
  title: string
  summary: string
  sections: string[]
}

export const ATA_CURRICULUM: Lesson[] = [
  {id:"market-basics",level:"beginner",title:"Market Basics",summary:"Learn price, volume, candles, trends and support/resistance.",sections:["Candlestick anatomy","Market structure","Support and resistance","Volume basics"]},
  {id:"risk-basics",level:"beginner",title:"Risk Management",summary:"Understand position sizing, risk per trade and stop-loss planning.",sections:["Risk per trade","Position sizing","Stop-loss placement","Trading discipline"]},
  {id:"indicators",level:"intermediate",title:"Technical Indicators",summary:"Learn RSI, Bollinger Bands, VWAP and indicator context.",sections:["Accurate RSI interpretation","Bollinger Bands","Anchored VWAP","Indicator confluence"]},
  {id:"futures",level:"intermediate",title:"Futures Trading",summary:"Understand leverage, margin, funding, liquidation and futures orders.",sections:["Margin","Leverage","Liquidation","Futures orders"]},
  {id:"advanced-structure",level:"advanced",title:"Advanced Market Structure",summary:"Build a repeatable multi-timeframe analysis process.",sections:["Multi-timeframe analysis","Liquidity concepts","Trend transitions","Trade planning"]},
  {id:"execution",level:"advanced",title:"Execution & Review",summary:"Learn execution, slippage, journaling and performance analysis.",sections:["Execution workflow","Slippage","Trade review","Performance metrics"]},
]
