export async function getSwapQuote(input: { wallet:string; fromToken:string; toToken:string; amount:string }) {
  const q = new URLSearchParams(input as Record<string,string>)
  const res = await fetch(`/api/swap/quote?${q.toString()}`)
  const data = await res.json()
  if (!res.ok) throw new Error(data.error || 'Unable to get live swap quote.')
  return data
}
export async function getBridgeQuote(input: { wallet:string; destinationChain:string; asset:string; amount:string }) {
  const q = new URLSearchParams(input as Record<string,string>)
  const res = await fetch(`/api/bridge/quote?${q.toString()}`)
  const data = await res.json()
  if (!res.ok) throw new Error(data.error || 'Unable to get live bridge quote.')
  return data
}
