export type AlertRule={type:"price"|"rsi"|"indicator";symbol:string;operator?:"above"|"below";value?:number;indicator?:string;condition?:string}
export interface AlertService{create(rule:AlertRule):Promise<{id:string}>;remove(id:string):Promise<void>;list():Promise<Array<{id:string;rule:AlertRule;active:boolean}>>}
