import { ARC_MAINNET } from "../arc/mainnet"
export type TokenSymbol = keyof typeof ARC_MAINNET.tokens
export function assertArcMainnet(chainId:number) {
  if (chainId !== ARC_MAINNET.chainId) throw new Error("ATA requires Arc Mainnet (5042).")
}
export function tokenAddress(token:TokenSymbol) { return ARC_MAINNET.tokens[token] }
export type Quote = {
  provider:"CIRCLE_CCTP_V2"|"LIFI"
  sourceChainId:number
  destinationChainId:number
  fromToken:TokenSymbol
  toToken?:TokenSymbol
  amount:string
  routeId?:string
}
