import { createOnrampKit, fetchOnrampSession } from '@circle-fin/onramp-kit'

const API = import.meta.env.VITE_API_BASE_URL || '/api'
export const onramp = createOnrampKit()

export async function createOnrampSession(walletAddress: string) {
  if (!walletAddress) throw new Error('Connect a user-controlled wallet first.')
  try {
    return await fetchOnrampSession({
      url: `${API}/onramp/session`,
      body: { destinationAddress: walletAddress, appUserId: walletAddress.toLowerCase() },
    })
  } catch (e: any) {
    let notReady = false
    try {
      const r = await fetch(`${API}/setup-check`)
      const j = await r.json()
      notReady = !j.circle
    } catch (_) {}
    if (notReady) throw new Error('Buying USDC is not set up yet. The site owner must add CIRCLE_API_KEY in Vercel and redeploy.')
    throw e
  }
}
