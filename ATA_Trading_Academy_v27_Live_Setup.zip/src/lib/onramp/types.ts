export type OnrampSession = {
  sessionId: string
  sessionToken: string
  walletAddress: string
  chainId: number
  asset: 'USDC'
  provider: string
  expiresAt?: string
  widgetUrl?: string
}
