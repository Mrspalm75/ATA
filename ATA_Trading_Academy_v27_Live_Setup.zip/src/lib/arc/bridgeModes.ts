export const ARC_CHAIN_ID = 5042
export const ARC_USDC = "0x3600000000000000000000000000000000000000"

export const BRIDGE_MODES = {
  CIRCLE_CCTP_V2: {
    id: "circle-cctp-v2",
    name: "Circle CCTP v2",
    description: "Native USDC in, native USDC out.",
    provider: "Circle CCTP v2",
  },
  LIFI: {
    id: "lifi",
    name: "LI.FI Bridge",
    description: "Cross-chain routes aggregated by LI.FI.",
    provider: "LI.FI",
    bridgeTools: [
      "across","gasZipBridge","relaydepository","polymer",
      "polymerStandard","lifiIntents","smartDeposits",
    ],
    exchangeTools: ["kyberswap","fly","lifiIntentsDex"],
  },
} as const
