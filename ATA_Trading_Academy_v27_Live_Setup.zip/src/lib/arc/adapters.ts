export type SwapQuote = {
  id: string
  fromChainId: number
  toChainId: number
  fromToken: string
  toToken: string
  fromAmount: string
  toAmount: string
  toAmountMin?: string
  fee?: string
  priceImpact?: string
  route?: string
  transactionRequest?: unknown
}

export type BridgeQuote = SwapQuote

export interface ArcSwapKitAdapter {
  getQuote(input: {
    walletAddress: string
    fromChainId: number
    toChainId: number
    fromToken: string
    toToken: string
    amount: string
    slippage?: number
  }): Promise<SwapQuote>
  executeQuote(input: { quote: SwapQuote; walletAddress: string }): Promise<{ transactionId?: string; status: string }>
}

export interface ArcBridgeAdapter {
  getQuote(input: {
    walletAddress: string
    fromChainId: number
    toChainId: number
    token: string
    amount: string
    recipient: string
  }): Promise<BridgeQuote>
  executeQuote(input: { quote: BridgeQuote; walletAddress: string }): Promise<{ transactionId?: string; status: string }>
}
