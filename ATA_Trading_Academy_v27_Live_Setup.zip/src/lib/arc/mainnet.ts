export const ARC_MAINNET = {
  chainId: 5042,
  chainIdHex: '0x13b2',
  networkName: 'Arc',
  rpcHost: 'arc-mainnet.infura.io',
  explorerUrl: 'https://explorer.arc.io',
  nativeCurrency: { name: 'USDC', symbol: 'USDC', decimals: 6 },
  cctpDomain: 26,
  tokens: {
    USDC: '0x3600000000000000000000000000000000000000',
    EURC: '0xbEf5f6d51CB62b58e6A8f77868681825C6fe21c1',
  },
  cctp: {
    TokenMessengerV2: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
    MessageTransmitterV2: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
    TokenMinterV2: '0xfd78EE919681417d192449715b2594ab58f5D002',
  },
  gateway: {
    Wallet: '0x77777777Dcc4d5A8B6E418Fd04D8997ef11000eE',
    Minter: '0x2222222d7164433c4C09B0b0D809a9b52C04C205',
  },
} as const

export const ARC_RPC_URL = (projectId: string) =>
  `https://arc-mainnet.infura.io/v3/${projectId}`
