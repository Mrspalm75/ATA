# ATA Trading Academy v9

ATA is structured as an independent trading platform with integrated DeFi wallet/funding/swap/earn capabilities.

The DeFi layer and real-trading execution layer are separate provider-adapter domains.
See `docs/ATA_DEFI_REAL_TRADING_INTEGRATION.md` for the production integration boundary.
