const ARC_DOMAIN = 26
const ARC_USDC = '0x3600000000000000000000000000000000000000'
const ARC_EURC = '0xbEf5f6d51CB62b58e6A8f77868681825C6fe21c1'

export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })
  try {
    const { sourceDomain, amount, sourceWallet, destinationWallet, destinationDomain, asset = 'USDC' } = req.body || {}
    if (Number(sourceDomain) !== ARC_DOMAIN) throw new Error('Bridge source must be Arc Mainnet domain 26.')
    if (!amount || !sourceWallet || !destinationWallet || destinationDomain === undefined) throw new Error('amount, sourceWallet, destinationWallet and destinationDomain are required.')
    if (Number(destinationDomain) === ARC_DOMAIN) throw new Error('Choose a destination chain other than Arc.')
    if (!['USDC', 'EURC'].includes(asset)) throw new Error('Unsupported bridge asset.')
    return res.status(200).json({
      status: 'prepared',
      message: `Arc ${asset} bridge intent prepared. The user must sign the live CCTP transaction in their wallet.`,
      sourceDomain: ARC_DOMAIN,
      destinationDomain: Number(destinationDomain),
      amount,
      asset,
      tokenAddress: asset === 'USDC' ? ARC_USDC : ARC_EURC,
      sourceWallet,
      destinationWallet,
      requiresWalletSignature: true,
    })
  } catch (e) {
    return res.status(400).json({ error: e.message || 'Unable to prepare bridge transfer.' })
  }
}
