const ARC_CHAIN_ID = 5042
const TOKENS = {
  USDC: "0x3600000000000000000000000000000000000000",
  EURC: "0xbEf5f6d51CB62b58e6A8f77868681825C6fe21c1",
}

function isAddress(value) { return /^0x[a-fA-F0-9]{40}$/.test(value || "") }
function isPositiveDecimal(value) { return /^\d+(?:\.\d+)?$/.test(value || "") && Number(value) > 0 }
function toUnits(value, decimals = 6) {
  const [whole, fraction = ""] = String(value).split(".")
  if (fraction.length > decimals) throw new Error(`Amount supports at most ${decimals} decimals.`)
  return BigInt(whole || "0") * (10n ** BigInt(decimals)) + BigInt((fraction + "0".repeat(decimals)).slice(0, decimals) || "0")
}

export default async function handler(req, res) {
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" })
  try {
    const { wallet, fromToken = "USDC", toToken = "EURC", amount, slippage = "0.003" } = req.query || {}
    if (!isAddress(wallet)) throw new Error("Connect a valid Arc wallet first.")
    if (!TOKENS[fromToken] || !TOKENS[toToken]) throw new Error("Unsupported Arc swap asset.")
    if (fromToken === toToken) throw new Error("Choose two different assets.")
    if (!isPositiveDecimal(amount)) throw new Error("Enter a valid swap amount.")

    const fromAmount = toUnits(amount, 6).toString()
    const params = new URLSearchParams({
      fromChain: String(ARC_CHAIN_ID), toChain: String(ARC_CHAIN_ID),
      fromToken: TOKENS[fromToken], toToken: TOKENS[toToken],
      fromAddress: wallet, toAddress: wallet, fromAmount,
      order: "FASTEST", slippage: String(slippage), integrator: process.env.LIFI_INTEGRATOR || "ata-trading-academy",
      allowBridges: "none",
    })
    const headers = { accept: "application/json" }
    if (process.env.LIFI_API_KEY) headers["x-lifi-api-key"] = process.env.LIFI_API_KEY
    const upstream = await fetch(`https://li.quest/v1/quote?${params.toString()}`, { headers })
    const data = await upstream.json().catch(() => ({}))
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.message || data?.error || `LI.FI returned ${upstream.status}` })
    return res.status(200).json(data)
  } catch (e) {
    return res.status(400).json({ error: e?.message || "Unable to get a live LI.FI quote." })
  }
}
