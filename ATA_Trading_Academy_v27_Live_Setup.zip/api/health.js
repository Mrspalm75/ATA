export default function handler(req, res) {
  res.status(200).json({
    ok: true,
    network: 'Arc',
    chainId: 5042,
    chainIdHex: '0x13b2',
    nativeGasCurrency: 'USDC',
    explorer: 'https://explorer.arc.io',
    onrampConfigured: Boolean(process.env.CIRCLE_API_KEY && process.env.CIRCLE_ONRAMP_API_BASE_URL && process.env.CIRCLE_ONRAMP_SESSION_PATH),
    cctpDomain: 26,
  })
}
