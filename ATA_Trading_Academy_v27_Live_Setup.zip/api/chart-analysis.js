import { askClaude, MENTOR_RULES } from './_claude.js'
export const config = { maxDuration: 60 }
const TYPES = ['image/jpeg', 'image/png', 'image/webp']
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })
  try {
    const { image, mediaType, context } = req.body || {}
    if (typeof image !== 'string' || !TYPES.includes(mediaType)) return res.status(400).json({ error: 'Upload a PNG, JPEG or WebP chart screenshot.' })
    if (image.length > 4_000_000) return res.status(413).json({ error: 'Image is too large. Try a smaller screenshot.' })
    const note = typeof context === 'string' ? context.slice(0, 600) : ''
    const prompt = `Walk me through this chart like a mentor talking a student through a setup. Cover, in order: 1) MARKET STRUCTURE (trend, swing highs/lows, breaks of structure), 2) KEY LEVELS (support, resistance, liquidity zones you can actually see), 3) POSSIBLE SCENARIOS (bullish and bearish, with the trigger for each), 4) ENTRY, STOP AND TARGET IDEAS with the invalidation level, 5) RISK (suggested risk per trade and approximate reward-to-risk), 6) WHAT TO WATCH next. Only describe what is visible; if the timeframe, instrument or levels are unclear, say so.${note ? `\nStudent context: ${note}` : ''}`
    const reply = await askClaude({
      system: MENTOR_RULES + ' You are reviewing an uploaded chart screenshot.',
      max_tokens: 1800,
      messages: [{ role: 'user', content: [{ type: 'image', source: { type: 'base64', media_type: mediaType, data: image } }, { type: 'text', text: prompt }] }],
    })
    return res.status(200).json({ reply })
  } catch (e) {
    return res.status(e.status || 500).json({ error: e.message || 'Chart analysis unavailable.' })
  }
}
