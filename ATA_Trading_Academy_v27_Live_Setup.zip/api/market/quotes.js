const CRYPTO = { bitcoin: 'BTC', ethereum: 'ETH', solana: 'SOL', ripple: 'XRP', cardano: 'ADA' }
const FX = ['EUR', 'GBP', 'JPY', 'CHF', 'AUD', 'CAD']

async function getJson(url, headers = {}) {
  const r = await fetch(url, { headers: { accept: 'application/json', ...headers } })
  if (!r.ok) throw new Error(`Provider returned ${r.status}`)
  return r.json()
}

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' })
  const type = String(req.query?.type || 'crypto')
  try {
    let items = []
    let source = ''
    if (type === 'crypto') {
      source = 'CoinGecko'
      const d = await getJson(`https://api.coingecko.com/api/v3/simple/price?ids=${Object.keys(CRYPTO).join(',')}&vs_currencies=usd&include_24hr_change=true`)
      items = Object.entries(CRYPTO).map(([id, sym]) => ({ symbol: `${sym}/USD`, price: d[id]?.usd, change: d[id]?.usd_24h_change }))
    } else if (type === 'forex') {
      source = 'ECB reference rates via Frankfurter (updated once per business day)'
      const d = await getJson(`https://api.frankfurter.dev/v1/latest?base=USD&symbols=${FX.join(',')}`)
      items = FX.map(c => {
        const rate = d.rates?.[c]
        const eurStyle = ['EUR', 'GBP', 'AUD'].includes(c)
        return { symbol: eurStyle ? `${c}/USD` : `USD/${c}`, price: rate ? (eurStyle ? 1 / rate : rate) : null, change: null }
      })
    } else {
      return res.status(400).json({ error: 'type must be crypto or forex' })
    }
    res.setHeader('cache-control', 's-maxage=15, stale-while-revalidate=30')
    return res.status(200).json({ type, source, updatedAt: new Date().toISOString(), items })
  } catch (e) {
    return res.status(502).json({ error: e?.message || 'Market data unavailable.' })
  }
}
