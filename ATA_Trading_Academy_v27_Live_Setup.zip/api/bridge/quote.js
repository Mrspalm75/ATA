const ARC_CHAIN_ID = 5042
const TOKENS = {
  USDC: "0x3600000000000000000000000000000000000000",
  EURC: "0xbEf5f6d51CB62b58e6A8f77868681825C6fe21c1",
}
function isAddress(value) { return /^0x[a-fA-F0-9]{40}$/.test(value || "") }
function isPositiveDecimal(value) { return /^\d+(?:\.\d+)?$/.test(value || "") && Number(value) > 0 }
function toUnits(value, decimals = 6) {
  const [whole, fraction = ""] = String(value).split(".")
  if (fraction.length > decimals) throw new Error(`Amount supports at most ${decimals} decimals.`)
  return (BigInt(whole || "0") * (10n ** BigInt(decimals)) + BigInt((fraction + "0".repeat(decimals)).slice(0, decimals) || "0")).toString()
}
export default async function handler(req, res) {
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" })
  try {
    const { wallet, destinationChain, asset = "USDC", amount } = req.query || {}
    if (!isAddress(wallet)) throw new Error("Connect your wallet before bridging.")
    if (!destinationChain || Number(destinationChain) === ARC_CHAIN_ID) throw new Error("Choose a destination chain other than Arc.")
    if (!TOKENS[asset]) throw new Error("Unsupported Arc bridge asset.")
    if (!isPositiveDecimal(amount)) throw new Error("Enter a valid bridge amount.")
    const params = new URLSearchParams({
      fromChain: String(ARC_CHAIN_ID), toChain: String(destinationChain),
      fromToken: TOKENS[asset], toToken: asset,
      fromAddress: wallet, toAddress: wallet, fromAmount: toUnits(amount),
      order: "FASTEST", slippage: "0.005", integrator: process.env.LIFI_INTEGRATOR || "ata-trading-academy",
      maxPriceImpact: "0.15",
    })
    const headers = { accept: "application/json" }
    if (process.env.LIFI_API_KEY) headers["x-lifi-api-key"] = process.env.LIFI_API_KEY
    const upstream = await fetch(`https://li.quest/v1/quote?${params.toString()}`, { headers })
    const data = await upstream.json().catch(() => ({}))
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.message || data?.error || `LI.FI returned ${upstream.status}` })
    // Never allow ATA to sign for a different wallet. The user must sign the returned transaction.
    if (data?.transactionRequest?.from && data.transactionRequest.from.toLowerCase() !== wallet.toLowerCase()) {
      return res.status(409).json({ error: "LI.FI returned a transaction for a different wallet. Route rejected." })
    }
    return res.status(200).json({ ...data, ata: { connectedWallet: wallet, destinationWallet: wallet, requiresConnectedWalletSignature: true } })
  } catch (e) {
    return res.status(400).json({ error: e?.message || "Unable to get a live bridge quote." })
  }
}
