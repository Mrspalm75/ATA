import { askClaude, MENTOR_RULES } from './_claude.js'
export const config = { maxDuration: 30 }
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })
  try {
    const raw = Array.isArray(req.body?.messages) ? req.body.messages : []
    const messages = raw.slice(-12)
      .filter(m => (m?.role === 'user' || m?.role === 'assistant') && typeof m.content === 'string' && m.content.trim())
      .map(m => ({ role: m.role, content: m.content.slice(0, 4000) }))
    if (!messages.length || messages[messages.length - 1].role !== 'user') return res.status(400).json({ error: 'Send a question first.' })
    while (messages[0].role !== 'user') messages.shift()
    const reply = await askClaude({ system: MENTOR_RULES, messages })
    return res.status(200).json({ reply })
  } catch (e) {
    return res.status(e.status || 500).json({ error: e.message || 'Mentor unavailable.' })
  }
}
