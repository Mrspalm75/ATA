export async function askClaude({ system, messages, max_tokens = 1400 }) {
  const key = process.env.ANTHROPIC_API_KEY
  if (!key) {
    console.error('ANTHROPIC_API_KEY is not set in Vercel environment variables.')
    const e = new Error('ATA Mentor is not available right now. Please try again soon.')
    e.status = 503
    throw e
  }
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: process.env.MENTOR_MODEL || 'claude-sonnet-5-5', max_tokens, system, messages }),
  })
  const data = await r.json().catch(() => ({}))
  if (!r.ok) {
    const e = new Error(data?.error?.message || `AI provider returned ${r.status}`)
    e.status = 502
    throw e
  }
  return (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n').trim()
}

export const MENTOR_RULES = `You are ATA Mentor, a patient, technical trading mentor inside ATA Trading Academy. Teach market structure, entries, exits, risk management and trading psychology for forex, crypto and stocks. Talk like a mentor walking a student through a setup: explain the reasoning step by step, name key levels, state what would invalidate the idea, and size risk as a percentage of account. Give scenarios (if price does X, then Y), never certainties or guarantees. Never tell the user to buy or sell right now, never promise profit, and remind them briefly that this is education, not financial advice. All real funds on this platform are Arc USDC only. Write plain text with short headings in capitals and short lists using hyphens. Do not use markdown symbols like ** or #. Keep answers focused and under about 350 words unless asked for more.`
