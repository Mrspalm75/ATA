// Shows which server settings are configured (true/false only, never the secret values).
export default function handler(req, res) {
  const has = k => Boolean(process.env[k])
  res.setHeader('cache-control', 'no-store')
  res.status(200).json({
    circle: has('CIRCLE_API_KEY'),
    circleReferrerDomain: has('CIRCLE_ONRAMP_REFERRER_DOMAIN'),
    mentor: has('ANTHROPIC_API_KEY'),
    lifi: has('LIFI_API_KEY'),
  })
}
