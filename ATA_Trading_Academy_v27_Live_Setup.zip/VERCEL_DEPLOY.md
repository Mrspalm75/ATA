# ATA Trading Academy — Vercel production setup

## Build
- Framework: Vite
- Build command: `npm run build`
- Output directory: `dist`
- Node.js: `24.x`

## Required server environment variables

Set these in Vercel **Project → Settings → Environment Variables → Production**:

```text
CIRCLE_API_KEY=YOUR_CIRCLE_ONRAMP_API_KEY
CIRCLE_ONRAMP_REFERRER_DOMAIN=YOUR_VERCEL_HOSTNAME
LIFI_API_KEY=YOUR_LIFI_PARTNER_API_KEY
LIFI_INTEGRATOR=ata-trading-academy
```

Optional frontend variable:

```text
VITE_INFURA_PROJECT_ID=YOUR_INFURA_PROJECT_ID
```

Never prefix `CIRCLE_API_KEY` or `LIFI_API_KEY` with `VITE_`. They must stay server-side.

## Circle Onramp
ATA creates a short-lived Circle Onramp session on the server and scopes the session to USDC on Arc and the connected wallet. The long-lived Circle API key never reaches the browser.

Production iframe embedding requires the exact deployed hostname to be authorized with Circle. If Circle has not authorized the hostname yet, the Onramp widget must be opened using Circle's supported top-level/popup flow instead of an iframe.

## LI.FI swap
ATA requests live quotes from the server, with Arc chain ID `5042`, and returns the transaction request to the browser. The connected wallet signs approvals and the swap transaction.

## LI.FI bridge
ATA requests a live route with:
- source chain: Arc `5042`
- source wallet: the currently connected wallet
- destination wallet: the same connected wallet

ATA rejects a route if LI.FI returns a transaction whose `from` address does not equal the connected wallet. The browser also verifies the wallet again before signing.

## Important
Do not put real API keys into `.env.example`, source files, Git, or the browser bundle. After adding production environment variables, redeploy the Vercel project.

## v25 market data

## v26

## v27 checklist (Vercel -> Settings -> Environment Variables, then Redeploy)
- CIRCLE_API_KEY (Circle Onramp key) and CIRCLE_ONRAMP_REFERRER_DOMAIN (your exact Vercel domain, no https://)
- ANTHROPIC_API_KEY (ATA Mentor and Chart Analysis)
- LIFI_API_KEY, LIFI_INTEGRATOR
Open /api/setup-check on your live site to see which of these are detected (true/false only).
