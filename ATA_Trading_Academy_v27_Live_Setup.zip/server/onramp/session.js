export async function createCircleOnrampSession({walletAddress,chainId,asset}){
  if(!process.env.CIRCLE_API_KEY) throw new Error('CIRCLE_API_KEY is not configured on the ATA server.')
  if(!process.env.CIRCLE_ONRAMP_API_BASE_URL || !process.env.CIRCLE_ONRAMP_SESSION_PATH) throw new Error('Circle Onramp API endpoint configuration is required before live funding is enabled.')
  const url=`${process.env.CIRCLE_ONRAMP_API_BASE_URL.replace(/\/$/,'')}/${process.env.CIRCLE_ONRAMP_SESSION_PATH.replace(/^\//,'')}`
  const response=await fetch(url,{method:'POST',headers:{'content-type':'application/json','Authorization':`Bearer ${process.env.CIRCLE_API_KEY}`},body:JSON.stringify({walletAddress,chainId,asset})})
  const data=await response.json().catch(()=>({}))
  if(!response.ok) throw new Error(data.error||data.message||`Circle Onramp returned ${response.status}`)
  return data
}
