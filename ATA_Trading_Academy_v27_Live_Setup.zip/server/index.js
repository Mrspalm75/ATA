import http from 'node:http'
import { createCircleOnrampSession } from './onramp/session.js'
import { prepareCctpTransfer } from './cctp/transfer.js'

const port=Number(process.env.PORT||8787)
const json=(res,status,data)=>{res.writeHead(status,{'content-type':'application/json'});res.end(JSON.stringify(data))}
const body=req=>new Promise((resolve,reject)=>{let s='';req.on('data',c=>s+=c);req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}});req.on('error',reject)})

const server=http.createServer(async(req,res)=>{
  try{
    if(req.method==='GET'&&req.url==='/api/health') return json(res,200,{ok:true,network:'Arc',chainId:5042,chainIdHex:'0x13b2',onramp:!!process.env.CIRCLE_API_KEY,cctp:true})
    if(req.method==='POST'&&req.url==='/api/onramp/session'){const b=await body(req);return json(res,200,await createCircleOnrampSession(b))}
    if(req.method==='POST'&&req.url==='/api/cctp/transfer'){const b=await body(req);return json(res,200,prepareCctpTransfer(b))}
    return json(res,404,{error:'Not found'})
  }catch(e){return json(res,400,{error:e.message})}
})
server.listen(port,()=>console.log(`ATA Arc Mainnet API listening on ${port}`))
