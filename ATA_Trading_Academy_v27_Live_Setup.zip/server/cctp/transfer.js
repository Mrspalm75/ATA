const ARC_DOMAIN=26
export function prepareCctpTransfer(body){
  const {sourceDomain,amount,sourceWallet,destinationWallet,destinationDomain,asset='USDC'}=body||{}
  if(Number(sourceDomain)!==ARC_DOMAIN) throw new Error('ATA bridge source must be Arc domain 26.')
  if(!amount||!sourceWallet||!destinationWallet||destinationDomain===undefined) throw new Error('amount, sourceWallet, destinationWallet and destinationDomain are required.')
  if(Number(destinationDomain)===ARC_DOMAIN) throw new Error('Choose a destination chain other than Arc.')
  if(!['USDC','EURC'].includes(asset)) throw new Error('Unsupported bridge asset.')
  return {status:'prepared',message:'Arc bridge intent created. Use the configured live Circle CCTP V2 provider/SDK to produce the wallet transaction, then have the user sign it.',sourceDomain:ARC_DOMAIN,destinationDomain:Number(destinationDomain),amount,asset,sourceWallet,destinationWallet}
}
