import { createOnrampKit, fetchOnrampSession } from '@circle-fin/onramp-kit'

const API = import.meta.env.VITE_API_BASE_URL || '/api'
export const onramp = createOnrampKit()

export async function createOnrampSession(walletAddress: string) {
  if (!walletAddress) throw new Error('Connect a user-controlled wallet first.')
  return fetchOnrampSession({
    url: `${API}/onramp/session`,
    body: { destinationAddress: walletAddress, appUserId: walletAddress.toLowerCase() },
  })
}
