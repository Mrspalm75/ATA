import React,{useEffect,useState} from 'react'
const API=import.meta.env.VITE_API_BASE_URL||'/api'
const fmt=p=>p==null?'—':p>=100?p.toFixed(2):p.toFixed(4)
export default function Markets({onSelect,selected}){
 const [type,setType]=useState('crypto');const [data,setData]=useState(null);const [err,setErr]=useState('')
 useEffect(()=>{let stop=false
  const run=async()=>{try{const r=await fetch(`${API}/market/quotes?type=${type}`);const j=await r.json();if(stop)return;if(!r.ok)throw new Error(j.error||'Market data unavailable.');setData(j);setErr('')}catch(e){if(!stop){setData(null);setErr(e.message)}}}
  setData(null);run();const t=setInterval(run,30000);return()=>{stop=true;clearInterval(t)}},[type])
 const b=on=>({padding:'10px 16px',borderRadius:10,border:'1px solid #30343b',background:on?'#fff':'#15181d',color:on?'#000':'#fff',cursor:'pointer'})
 return <section style={{padding:28,border:'1px solid #292e36',borderRadius:18,background:'#0d1015',marginTop:18}}>
  <h2>Live markets</h2>
  <div style={{display:'flex',gap:8,flexWrap:'wrap',margin:'14px 0'}}>{[['crypto','Crypto'],['forex','Forex'],['stocks','Stocks']].map(([k,l])=><button key={k} style={b(k===type)} onClick={()=>setType(k)}>{l}</button>)}</div>
  {err&&<div style={{color:'#f0b429'}}>{err}</div>}
  {!data&&!err&&<div style={{color:'#9da5b0'}}>Loading…</div>}
  {data&&<><div style={{overflowX:'auto'}}><table style={{width:'100%',borderCollapse:'collapse'}}><tbody>{data.items.map(i=><tr key={i.symbol} onClick={()=>onSelect({...i,type})} style={{cursor:'pointer',borderBottom:'1px solid #242830',background:selected?.symbol===i.symbol?'#161b22':'transparent'}}><td style={{padding:12,fontWeight:700}}>{i.symbol}</td><td style={{padding:12}}>{fmt(i.price)}</td><td style={{padding:12,color:i.change==null?'#8e96a3':i.change>=0?'#3ddc97':'#ff6b6b'}}>{i.change==null?'—':i.change.toFixed(2)+'%'}</td></tr>)}</tbody></table></div><div style={{color:'#707986',fontSize:12,marginTop:8}}>Source: {data.source} · refreshed {new Date(data.updatedAt).toLocaleTimeString()}</div></>}
 </section>
}
