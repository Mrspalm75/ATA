import { createOnrampServerKit, createSessionRouteHandler } from "@circle-fin/onramp-kit/server"

const apiKey = process.env.CIRCLE_API_KEY
const referrerDomain = process.env.CIRCLE_ONRAMP_REFERRER_DOMAIN

let server
if (apiKey) {
  server = createOnrampServerKit({
    apiKey,
    ...(referrerDomain ? { referrerDomain } : {}),
  })
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" })
  if (!server) return res.status(503).json({ error: "Circle Onramp is not configured. Add CIRCLE_API_KEY in Vercel." })

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {})
    const walletAddress = body.destinationAddress || body.walletAddress
    if (!walletAddress) return res.status(400).json({ error: "Connect your wallet before buying Arc USDC." })
    if (!/^0x[a-fA-F0-9]{40}$/.test(walletAddress)) return res.status(400).json({ error: "Invalid connected wallet address." })

    const request = new Request("https://ata.local/api/onramp/session", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        appUserId: walletAddress.toLowerCase(),
        destinationAddress: walletAddress,
        assets: { pairs: [{ token: "USDC", chain: "arc" }] },
      }),
    })

    const response = await createSessionRouteHandler(server)(request)
    const text = await response.text()
    res.status(response.status).setHeader("cache-control", "no-store").send(text)
  } catch (e) {
    res.status(500).json({ error: e?.message || "Unable to create Circle Onramp session." })
  }
}
